from django.urls import path
from . import views
from django.contrib.auth import views as auth_views
from django.contrib import admin
urlpatterns = [
    path('', views.home, name='home'),
    path('registro/', views.registro, name='registro'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('citas/', views.listar_citas, name='listar_citas'),
    path('citas/nueva/', views.crear_cita, name='crear_cita'),
    path('citas/cancelar/<int:cita_id>/', views.cancelar_cita, name='cancelar_cita'),
    path('ajax/cargar-medicos/', views.cargar_medicos, name='ajax_cargar_medicos'),
    path('ajax/cargar_disponibilidad/', views.ajax_cargar_disponibilidad, name='ajax_cargar_disponibilidad'),
    path('eliminar_cita/<int:cita_id>/', views.eliminar_cita, name='eliminar_cita'),
    path('sobre_nosotros/', views.sobre_nosotros, name='sobre_nosotros'),
    path('servicios/', views.servicios, name='servicios'),
    path('programas/', views.programas, name='programas'),
    path('ordenamientos/', views.ordenamientos, name='ordenamientos'),
    path('laboratorio/', views.laboratorio, name='laboratorio'),
    path('imagenologia/', views.imagenologia, name='imagenologia'),
    path("autorizaciones/", views.autorizaciones, name="autorizaciones"),
    path("medicamentos/", views.medicamentos, name="medicamentos"),
    path("incapacidades/", views.incapacidades, name="incapacidades"),
    path('api/fechas-lab/', views.api_fechas_disponibles, name='api_fechas_lab'),

    path("ordenes_laboratorio_medico/", views.ordenes_laboratorio_medico, name="ordenes_laboratorio_medico"),
    path("autorizaciones_medico/", views.autorizaciones_medico, name="autorizaciones_medico"),
    path("ordenamientos_medico/", views.ordenamientos_medico, name="ordenamientos_medico"),
    path("imagenologia_medico/", views.imagenologia_medico, name="imagenologia_medico"),
    path('perfil_medico/', views.perfil_medico, name='perfil_medico'),
    path('medico/citas/', views.citas_medico, name='citas_medico'),

    #  RECUPERAR CONTRASEÑA 
    path('password_reset/', auth_views.PasswordResetView.as_view(), name='password_reset'),
    path('password_reset/done/', auth_views.PasswordResetDoneView.as_view(), name='password_reset_done'),
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('reset/done/', auth_views.PasswordResetCompleteView.as_view(), name='password_reset_complete'),

    # ADMIN
    path('admin/', admin.site.urls),

    # INCAPACIDADES
    path("medico/incapacidades/", views.incapacidades_medico, name="incapacidades_listas"),
    path("medico/incapacidades/nueva/", views.crear_incapacidad, name="crear_incapacidad"),
    path("medico/incapacidades/editar/<int:id>/", views.editar_incapacidad, name="editar_incapacidad"),
    path("medico/incapacidades/eliminar/<int:id>/", views.eliminar_incapacidad, name="eliminar_incapacidad"),
    path("medico/incapacidades/<int:id>/", views.detalle_incapacidad, name="detalle_incapacidad"),

    path('medicamentos_medicos/', views.medicamentos_medicos, name='medicamentos_medicos'),
    path('medico/autorizaciones/<int:paciente_id>/', views.gestionar_autorizaciones, name='gestionar_autorizaciones'),
    path('medico/cita/<int:cita_id>/', views.detalle_cita, name='detalle_cita'),
    path('medico/autorizaciones/<int:paciente_id>/', views.gestionar_autorizaciones, name='gestionar_autorizaciones'),
    path('medico/orden/<int:cita_id>/', views.generar_orden, name='generar_orden'),
    path("ajax/buscar-paciente/", views.buscar_paciente_por_documento, name="buscar_paciente"),

]
