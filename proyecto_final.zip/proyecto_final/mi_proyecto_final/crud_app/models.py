from django.db import models
from django.contrib.auth.models import User
from datetime import date, datetime, timedelta
import calendar 
from django.db.models.signals import post_save
from django.dispatch import receiver

class PerfilUsuario(models.Model):
    ROLES = [
        ('PACIENTE', 'Paciente'),
        ('MEDICO', 'Médico'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="perfilusuario")
    rol = models.CharField(max_length=20, choices=ROLES, default='PACIENTE')
    numero_documento = models.CharField(max_length=40, blank=True, null=True)
    eps = models.CharField(max_length=100, blank=True, null=True)
    
    def __str__(self):
        return f"{self.user.username} - {self.rol}"


class Especialidad(models.Model):
    nombre = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre


class Medico(models.Model):
    usuario = models.OneToOneField(User, on_delete=models.CASCADE)
    especialidad = models.ForeignKey(Especialidad, on_delete=models.CASCADE)
    dias_trabajo = models.CharField(max_length=100, null=True, blank=True, help_text="Ejemplo: lunes,martes,jueves")
    hora_inicio = models.TimeField()
    hora_fin = models.TimeField()

    def __str__(self):
        return f"{self.usuario.first_name} {self.usuario.last_name} - {self.especialidad.nombre}"
    
class HorarioDisponible(models.Model):
    medico = models.ForeignKey('Medico', on_delete=models.CASCADE, related_name="horarios_disponibles")
    fecha = models.DateField()
    hora = models.TimeField()
    disponible = models.BooleanField(default=True)

    class Meta:
        unique_together = ('medico', 'fecha', 'hora')
        ordering = ['fecha', 'hora']

    def __str__(self):
        estado = "Disponible" if self.disponible else "Ocupado"
        return f"{self.medico} - {self.fecha} {self.hora} ({estado})"

    @staticmethod
    def generar_horarios(medico):
        dias_trabajo = [d.strip().lower() for d in medico.dias_trabajo.split(',')]
        hoy = date.today()

        # 🔹 Diccionario de traducción inglés → español
        traducir = {
            'monday': 'lunes',
            'tuesday': 'martes',
            'wednesday': 'miércoles',
            'thursday': 'jueves',
            'friday': 'viernes',
            'saturday': 'sábado',
            'sunday': 'domingo'
        }

        for i in range(21):  # próximas 3 semanas
            fecha = hoy + timedelta(days=i)
            # Obtener el nombre del día en español
            dia_nombre = traducir.get(calendar.day_name[fecha.weekday()].lower(), '').lower()

            # Solo generar horarios si coincide con los días de trabajo del médico
            if dia_nombre in dias_trabajo:
                hora_actual = datetime.combine(fecha, medico.hora_inicio)
                fin = datetime.combine(fecha, medico.hora_fin)
                while hora_actual < fin:
                    HorarioDisponible.objects.get_or_create(
                        medico=medico,
                        fecha=fecha,
                        hora=hora_actual.time()
                    )
                    hora_actual += timedelta(minutes=30)  # cada media hora

class Cita(models.Model):
    paciente = models.ForeignKey(User, on_delete=models.CASCADE, related_name='citas')
    especialidad = models.ForeignKey(Especialidad, on_delete=models.CASCADE, null=True, blank=True)  # ✅ añadido
    medico = models.ForeignKey(Medico, on_delete=models.CASCADE)
    fecha = models.DateTimeField()
    motivo = models.TextField()
    estado = models.CharField(
        max_length=20,
        choices=[
            ('pendiente', 'Pendiente'),
            ('confirmada', 'Confirmada'),
            ('cancelada', 'Cancelada'),
            ('atendida', 'Atendida'),
        ],
        default='confirmada'
    )

    def __str__(self):
        return f"Cita con {self.medico} - {self.fecha.strftime('%Y-%m-%d %H:%M')}"
    
    def save(self, *args, **kwargs):
        from .models import HorarioDisponible  # para evitar import circular
        super().save(*args, **kwargs)
        # Cuando se guarda la cita, el horario se marca como no disponible
        HorarioDisponible.objects.filter(
            medico=self.medico,
            fecha=self.fecha.date(),
            hora=self.fecha.time()
        ).update(disponible=False)

class SedeLaboratorio(models.Model):
    nombre = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre


class FechaDisponibleLab(models.Model):
    sede = models.ForeignKey(SedeLaboratorio, on_delete=models.CASCADE, related_name="fechas")
    fecha = models.DateField()

    class Meta:
        unique_together = ('sede', 'fecha')
        ordering = ['fecha']

    def __str__(self):
        return f"{self.sede} - {self.fecha}"


class HoraDisponibleLab(models.Model):
    fecha = models.ForeignKey(FechaDisponibleLab, on_delete=models.CASCADE, related_name="horas")
    hora = models.TimeField()

    disponible = models.BooleanField(default=True)

    class Meta:
        unique_together = ('fecha', 'hora')
        ordering = ['hora']

    def __str__(self):
        estado = "Disponible" if self.disponible else "Ocupado"
        return f"{self.fecha.fecha} - {self.hora} ({estado})"
    
    # Agregar campo EPS dinámicamente
setattr(User, 'eps', models.CharField(max_length=100, default="", blank=True))


@receiver(post_save, sender=User)
def crear_perfil_usuario(sender, instance, created, **kwargs):
    if created:
        PerfilUsuario.objects.create(user=instance)

class Autorizacion(models.Model):
    ESTADOS = (
        ('pendiente', 'Pendiente'),
        ('aprobada', 'Aprobada'),
        ('rechazada', 'Rechazada'),
        ('cancelada', 'Cancelada'),
    )

    paciente = models.ForeignKey(User, on_delete=models.CASCADE)
    medico = models.ForeignKey(Medico, on_delete=models.SET_NULL, null=True)
    servicio = models.CharField(max_length=200)
    fecha_solicitud = models.DateTimeField(auto_now_add=True)
    estado = models.CharField(max_length=20, choices=ESTADOS, default='pendiente')

    def _str_(self):
        return f"{self.servicio} | {self.paciente.username}"
    
    # Asignar rol MEDICO automáticamente cuando se crea un médico desde el admin
@receiver(post_save, sender=Medico)
def asignar_rol_medico(sender, instance, created, **kwargs):
    if created:
        perfil, _ = PerfilUsuario.objects.get_or_create(user=instance.usuario)
        perfil.rol = "MEDICO"
        perfil.save()

class Incapacidad(models.Model):
    paciente = models.ForeignKey(User, on_delete=models.CASCADE)
    medico = models.ForeignKey(Medico, on_delete=models.CASCADE)
    diagnostico = models.TextField()
    dias = models.PositiveIntegerField()
    fecha_emision = models.DateField(auto_now_add=True)
    fecha_inicio = models.DateField()
    fecha_fin = models.DateField()
    estado = models.CharField(
        max_length=20,
        choices=[
            ('activa', 'Activa'),
            ('finalizada', 'Finalizada'),
            ('anulada', 'Anulada'),
        ],
        default='activa'
    )

    def _str_(self):
        return f"Incapacidad de {self.paciente.username} ({self.fecha_inicio} → {self.fecha_fin})"
    
class Ordenamiento(models.Model):
    paciente = models.ForeignKey(User, on_delete=models.CASCADE)
    medico = models.ForeignKey(Medico, on_delete=models.CASCADE)
    tipo_servicio = models.CharField(max_length=100, default="Ordenamiento Médico")
    contenido = models.TextField()
    fecha = models.DateTimeField(auto_now_add=True)

    def remisor(self):
        return f"{self.medico.usuario.first_name} {self.medico.usuario.last_name}"

    def __str__(self):
        return f"Ordenamiento de {self.paciente.first_name} {self.paciente.last_name}"
    
class Receta(models.Model):
    paciente = models.ForeignKey(User, on_delete=models.CASCADE)
    medico = models.ForeignKey(Medico, on_delete=models.CASCADE)
    medicamento = models.CharField(max_length=200)
    indicaciones = models.TextField()
    fecha = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Receta de {self.paciente} - {self.medicamento}"



