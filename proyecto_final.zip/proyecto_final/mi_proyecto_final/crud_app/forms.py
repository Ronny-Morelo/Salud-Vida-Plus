from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import Cita, Especialidad, Medico, Autorizacion
from .models import PerfilUsuario

class RegistroPacienteForm(UserCreationForm):
    email = forms.EmailField(required=True)

    numero_documento = forms.CharField(label="Número de documento")

    EPS_CHOICES = [
        ("Selecciona tu EPS", "Selecciona tu EPS"),
        ("Nueva EPS", "Nueva EPS"),
        ("SURA", "SURA"),
        ("Mutual Ser", "Mutual Ser"),
        ("Compensar", "Compensar"),
        ("Coosalud", "Coosalud"),
        ("Cajacopi", "Cajacopi"),
        ("Salud Total", "Salud Total"),
    ]
    
    eps = forms.ChoiceField(
        choices=EPS_CHOICES,
        required=True,
        label="EPS",
        widget=forms.Select(attrs={'class': 'reg-input'})
    )

    class Meta:
        model = User
        fields = [
            'username',
            'first_name',
            'last_name',
            'email',
            'numero_documento',
            'eps',
            'password1',
            'password2'
        ]

    def save(self, commit=True):
        user = super().save(commit)

        # Actualizar datos del perfil automáticamente
        perfil, creado = PerfilUsuario.objects.get_or_create(user=user)

        perfil.numero_documento = self.cleaned_data['numero_documento']
        perfil.eps = self.cleaned_data['eps']
        perfil.rol = "PACIENTE"   # ✔ ROl FIJO — NO SE PIDE EN FORMULARIO
        perfil.save()

        return user

class CitaForm(forms.ModelForm):
    especialidad = forms.ModelChoiceField(
        queryset=Especialidad.objects.all(),
        required=True,
        label="Especialidad"
    )
    
    class Meta:
        model = Cita
        fields = ['especialidad', 'medico', 'fecha', 'motivo']
        widgets = {
            'fecha': forms.Select(attrs={'class': 'form-control'}),  # 🔹 Cambiado para mostrar lista de fechas disponibles
            'motivo': forms.Textarea(attrs={'rows': 3, 'class': 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Médicos vacíos por defecto
        self.fields['medico'].queryset = Medico.objects.none()
        self.fields['fecha'].choices = []  # Inicialmente sin fechas

        # Si se seleccionó una especialidad
        if 'especialidad' in self.data:
            try:
                especialidad_id = int(self.data.get('especialidad'))
                self.fields['medico'].queryset = Medico.objects.filter(especialidad_id=especialidad_id)
            except (ValueError, TypeError):
                pass
        elif self.instance.pk:
            # Si ya existe la cita, mostrar los médicos de esa especialidad
            self.fields['medico'].queryset = self.instance.especialidad.medico_set.all()

        # 🔹 Filtrar fechas disponibles según el médico seleccionado
        from .models import HorarioDisponible
        if 'medico' in self.data:
            try:
                medico_id = int(self.data.get('medico'))
                fechas = HorarioDisponible.objects.filter(
                    medico_id=medico_id,
                    disponible=True
                ).values_list('fecha', flat=True).distinct()

                self.fields['fecha'].choices = [(f, f) for f in fechas]
            except (ValueError, TypeError):
                pass

class AutorizacionForm(forms.ModelForm):
    class Meta:
        model = Autorizacion
        fields = ['medico', 'servicio']
        widgets = {
            'servicio': forms.TextInput(attrs={'class': 'form-control'}),
        }