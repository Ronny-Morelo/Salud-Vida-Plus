from django.shortcuts import redirect

def medico_required(view_func):
    def wrapper(request, *args, **kwargs):
        perfil = getattr(request.user, "perfilusuario", None)

        if not request.user.is_authenticated:
            return redirect("login")

        # Si NO es médico → redirigir a HOME (paciente)
        if perfil is None or perfil.rol.upper() != "MEDICO":
            return redirect("home")

        return view_func(request, *args, **kwargs)

    return wrapper


def paciente_required(view_func):
    def wrapper(request, *args, **kwargs):
        perfil = getattr(request.user, "perfilusuario", None)

        if not request.user.is_authenticated:
            return redirect("login")

        # Si NO es paciente → redirigir al PERFIL DEL MÉDICO
        if perfil is None or perfil.rol.upper() != "PACIENTE":
            return redirect("perfil_medico")

        return view_func(request, *args, **kwargs)

    return wrapper