from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.mail import EmailMessage
from .forms import RegistroPacienteForm, CitaForm
from .models import Cita, Medico, HorarioDisponible, Incapacidad, Autorizacion
from django.http import JsonResponse, HttpResponseForbidden
from .models import SedeLaboratorio, FechaDisponibleLab
from .models import PerfilUsuario
from .decorators import medico_required, paciente_required
from .models import Receta


def registro(request):
    if request.method == 'POST':
        form = RegistroPacienteForm(request.POST)
        if form.is_valid():
            user = form.save() 
            messages.success(request, "Registro exitoso. Ahora puedes iniciar sesión.")

            # 🔹 Forzar el rol PACIENTE automáticamente
            perfil, creado = PerfilUsuario.objects.get_or_create(user=user)
            perfil.rol = "PACIENTE"
            perfil.save()

            login(request, user)
            return redirect('login')
    else:
        form = RegistroPacienteForm()
    return render(request, 'crud_app/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)

            perfil = getattr(user, 'perfilusuario', None)

            # Crear perfil si no existe
            if perfil is None:
                perfil = PerfilUsuario.objects.create(user=user, rol='PACIENTE')

            rol = perfil.rol.lower()

            if rol == 'medico':
                return redirect('perfil_medico')

            return redirect('home')

        # Credenciales incorrectas
        return render(request, 'crud_app/login.html', {
            'error': 'Credenciales incorrectas.'
        })

    #  MUY IMPORTANTE: manejar GET
    return render(request, 'crud_app/login.html')

@login_required
@paciente_required
def home(request):
    nombre = request.user.get_full_name() or request.user.username

    if not request.session.get('welcomed'):
        messages.success(request, f"BIENVENIDO Sr(a) {nombre.upper()}")
        request.session['welcomed'] = True

    return render(request, 'crud_app/home.html')


@login_required
@medico_required
def perfil_medico(request):
    medico, created = Medico.objects.get_or_create(usuario=request.user)
    return render(request, 'crud_app/perfil_medico.html', {'medico': medico})
    

@login_required
@medico_required
def citas_medico(request):
    medico = Medico.objects.get(usuario=request.user)  # ✔ Obtener el Médico 

    citas = Cita.objects.filter(medico=medico).order_by("fecha")  # YA NO USAS hora

    return render(request, "crud_app/citas_medico.html", {
        "citas": citas
    })

@login_required
@medico_required
def detalle_cita(request, cita_id):
    cita = get_object_or_404(Cita, id=cita_id, medico=request.user)
    return render(request, 'crud_app/detalle_cita.html', {'cita': cita})

@login_required
@medico_required
def generar_orden(request, cita_id):
    cita = get_object_or_404(Cita, id=cita_id, medico=request.user)

    if request.method == "POST":
        descripcion = request.POST.get("descripcion")
        OrdenLaboratorio.objects.create( # type: ignore
            cita=cita,
            paciente=cita.paciente,
            medico=request.user,
            descripcion=descripcion,
        )
        return redirect('detalle_cita', cita_id=cita.id)

    return render(request, 'crud_app/generar_orden.html', {"cita": cita})

@login_required
@medico_required
def gestionar_autorizaciones(request, paciente_id):
    autorizaciones = Autorizacion.objects.filter(paciente_id=paciente_id)
    return render(request, 'crud_app/gestionar_autorizaciones.html', {"autorizaciones": autorizaciones})

# views.py (añadir estas funciones)
from django.views.decorators.http import require_POST

@login_required
@medico_required
def ordenes_laboratorio_medico(request):
    """Página donde el médico crea y ve órdenes de laboratorio enviadas."""
    medico = Medico.objects.get(usuario=request.user)
    # TODO: sustituir por un modelo OrdenLaboratorio si lo tienes
    ordenes = []  # placeholder: traer órdenes relacionadas al médico
    if request.method == "POST":
        # ejemplo simple: recibir datos del form y crear orden (implementar modelo)
        nombre = request.POST.get("nombre")
        descripcion = request.POST.get("descripcion")
        # aquí crearías la orden en DB
        return redirect('ordenes_laboratorio_medico')

    return render(request, 'crud_app/ordenes_laboratorio_medico.html', {'medico': medico, 'ordenes': ordenes})


@login_required
@medico_required
def autorizaciones_medico(request):
    """Listar autorizaciones que pacientes solicitaron y permitir aprobar/rechazar."""
    # muestra autorizaciones pendientes
    autorizaciones = Autorizacion.objects.filter(estado='pendiente').order_by('-fecha_solicitud')
    if request.method == 'POST':
        accion = request.POST.get('accion')
        aut_id = request.POST.get('aut_id')
        aut = get_object_or_404(Autorizacion, id=aut_id)
        if accion == 'aprobar':
            aut.estado = 'aprobada'
            aut.save()
        elif accion == 'rechazar':
            aut.estado = 'rechazada'
            aut.save()
        return redirect('autorizaciones_medico')

    return render(request, 'crud_app/autorizaciones_medico.html', {'autorizaciones': autorizaciones})


from .models import Ordenamiento, PerfilUsuario, Medico
from django.contrib import messages

@login_required
@medico_required
def ordenamientos_medico(request):
    medico = Medico.objects.get(usuario=request.user)

    # Obtener todos los ordenamientos creados por el médico
    ordenamientos = Ordenamiento.objects.filter(medico=medico).order_by('-fecha')

    if request.method == "POST":
        numero_documento = request.POST.get("numero_documento")
        contenido = request.POST.get("contenido")

        # buscar paciente por documento
        try:
            perfil = PerfilUsuario.objects.get(numero_documento=numero_documento)
            paciente = perfil.user
        except PerfilUsuario.DoesNotExist:
            messages.error(request, "Paciente no encontrado.")
            return redirect("ordenamientos_medico")

        # crear ordenamiento
        Ordenamiento.objects.create(
            paciente=paciente,
            medico=medico,
            contenido=contenido,
            tipo_servicio="Ordenamiento Médico"
        )

        messages.success(request, "Ordenamiento guardado correctamente.")
        return redirect("ordenamientos_medico")

    return render(request, "crud_app/ordenamientos_medico.html", {
        "medico": medico,
        "ordenamientos": ordenamientos
    })

@login_required
def ordenamientos(request):
    ordenamientos = Ordenamiento.objects.filter(paciente=request.user).order_by('-fecha')

    return render(request, "crud_app/ordenamientos.html", {
        "ordenamientos": ordenamientos
    })


@login_required
@medico_required
def imagenologia_medico(request):
    """Solicitar y revisar estudios de imagen (radiografías, ecografías...)."""
    medico = Medico.objects.get(usuario=request.user)
    estudios = []  # placeholder: traer estudios creados por médico
    if request.method == 'POST':
        tipo = request.POST.get('tipo')
        descripcion = request.POST.get('descripcion')
        paciente_id = request.POST.get('paciente')
        # guardar estudio en DB
        return redirect('imagenologia_medico')

    return render(request, 'crud_app/imagenologia_medico.html', {'medico': medico, 'estudios': estudios})

@login_required
@medico_required
def medicamentos_medicos(request):
    medico = Medico.objects.get(usuario=request.user)

    if request.method == 'POST':
        numero_documento = request.POST.get("numero_documento")
        medicamento = request.POST.get("medicamento")
        indicaciones = request.POST.get("indicaciones")

        # Buscar paciente por documento
        try:
            perfil = PerfilUsuario.objects.get(numero_documento=numero_documento)
            paciente = perfil.user
        except PerfilUsuario.DoesNotExist:
            messages.error(request, "Paciente no encontrado.")
            return redirect("medicamentos_medicos")

        # Crear receta
        Receta.objects.create(
            medico=medico,
            paciente=paciente,
            medicamento=medicamento,
            indicaciones=indicaciones
        )

        messages.success(request, "Receta emitida correctamente.")
        return redirect("medicamentos_medicos")

    # Mostrar recetas del médico
    recetas = Receta.objects.filter(medico=medico).order_by("-fecha")

    return render(request, 'crud_app/medicamentos_medicos.html', {
        'medico': medico,
        'recetas': recetas
    })


# LISTAR INCAPACIDADES
@login_required
@medico_required
def incapacidades_medico(request):
    medico = Medico.objects.get(usuario=request.user)
    incapacidades = Incapacidad.objects.filter(medico=medico)

    return render(request, "crud_app/incapacidades_listas.html", {
        "incapacidades": incapacidades
    })



# CREAR INCAPACIDAD
@login_required
@medico_required
def crear_incapacidad(request):
    medico = Medico.objects.get(usuario=request.user)

    if request.method == "POST":
        numero_documento = request.POST.get("numero_documento")  # 🔥 SOLO DOCUMENTO

        # Buscar paciente por documento
        try:
            perfil = PerfilUsuario.objects.get(numero_documento=numero_documento)
            paciente = perfil.user
        except PerfilUsuario.DoesNotExist:
            messages.error(request, "Paciente no encontrado.")
            return redirect("crear_incapacidad")

        diagnostico = request.POST.get("diagnostico")
        dias = int(request.POST.get("dias"))
        fecha_inicio = request.POST.get("fecha_inicio")
        fecha_fin = request.POST.get("fecha_fin")

        # Crear incapacidad
        Incapacidad.objects.create(
            paciente=paciente,
            medico=medico,
            diagnostico=diagnostico,
            dias=dias,
            fecha_inicio=fecha_inicio,
            fecha_fin=fecha_fin,
        )

        messages.success(request, "Incapacidad creada correctamente.")
        return redirect("incapacidades_listas")

    return render(request, "crud_app/incapacidades_form.html")



# DETALLE
@login_required
def detalle_incapacidad(request, id):
    incapacidad = get_object_or_404(Incapacidad, id=id)
    return render(request, "crud_app/incapacidades_detalle.html", {
        "incapacidad": incapacidad
    })


# EDITAR
@login_required
def editar_incapacidad(request, id):
    incapacidad = get_object_or_404(Incapacidad, id=id)

    if request.method == "POST":
        incapacidad.diagnostico = request.POST.get("diagnostico")
        incapacidad.dias = request.POST.get("dias")
        incapacidad.fecha_inicio = request.POST.get("fecha_inicio")
        incapacidad.fecha_fin = request.POST.get("fecha_fin")
        incapacidad.estado = request.POST.get("estado")
        incapacidad.save()

        messages.success(request, "Incapacidad modificada correctamente.")
        return redirect("incapacidades_listas")

    return render(request, "crud_app/incapacidades_edit.html", {
        "incapacidad": incapacidad
    })


# ELIMINAR
@login_required
def eliminar_incapacidad(request, id):
    incapacidad = get_object_or_404(Incapacidad, id=id)
    incapacidad.delete()
    messages.success(request, "Incapacidad eliminada.")
    return redirect("incapacidades_listas")


@login_required
def listar_citas(request):
    citas = Cita.objects.filter(paciente=request.user).order_by('-fecha')
    return render(request, 'crud_app/citas_list.html', {'citas': citas})

@login_required
def listar_citas(request):
    citas = Cita.objects.filter(paciente=request.user).order_by('-fecha')
    return render(request, 'crud_app/citas_list.html', {'citas': citas})

@login_required
def crear_cita(request):
    if request.method == 'POST':
        form = CitaForm(request.POST)
        if form.is_valid():
            cita = form.save(commit=False)
            cita.paciente = request.user
            cita.save()

            # Enviar correo de confirmación con codificación UTF-8
            mensaje = (
                f"Hola {request.user.first_name},\n\n"
                f"Tu cita ha sido agendada con Exito.\n\n"
                f"Médico: {cita.medico}\n"
                f"Fecha: {cita.fecha.strftime('%Y-%m-%d %H:%M')}\n"
                f"Motivo: {cita.motivo}\n\n"
                f"Si deseas cancelar o modificar tu cita, ingresa a la plataforma.\n\n"
                f"Gracias por usar nuestro servicio."
            )

            email = EmailMessage(
                subject="Confirmación de tu cita médica",
                body=mensaje,
                from_email=None,  # Usa el DEFAULT_FROM_EMAIL del settings.py
                to=[request.user.email],
            )
            email.encoding = 'utf-8'  # 🔥 Esto soluciona el error
            email.send()
            return JsonResponse({'success': True, 'mensaje': "Cita agendada correctamente."})
        else:
            return JsonResponse({'success': False, 'errors': form.errors}, status=400)
    else:
        form = CitaForm()
    return render(request, 'crud_app/crear_cita.html', {'form': form})

def cargar_medicos(request):
    especialidad_id = request.GET.get('especialidad')

    # Filtramos los médicos de esa especialidad
    medicos = Medico.objects.filter(especialidad_id=especialidad_id)

    data = []
    for medico in medicos:
        # Validamos que el médico tenga usuario antes de acceder a él
        if medico.usuario:
            data.append({
                'id': medico.id,
                'nombre': medico.usuario.first_name or '',
                'apellido': medico.usuario.last_name or '',
            })

    return JsonResponse(data, safe=False)

def ajax_cargar_disponibilidad(request):
    medico_id = request.GET.get('medico')
    if not medico_id:
        return JsonResponse([], safe=False)

    # Buscar los horarios disponibles del médico
    horarios = HorarioDisponible.objects.filter(medico_id=medico_id, disponible=True)

    data = []
    for h in horarios:
        data.append({
            'id': h.id,
            'fecha': h.fecha.strftime("%Y-%m-%d"),
            'hora': h.hora.strftime("%H:%M")  # 🔹 corregido
        })

    return JsonResponse(data, safe=False)



@login_required
def cancelar_cita(request, cita_id):
    cita = Cita.objects.get(id=cita_id, paciente=request.user)
    cita.estado = 'cancelada'
    cita.save()
    return redirect('listar_citas')

@login_required
def eliminar_cita(request, cita_id):
    cita = get_object_or_404(Cita, id=cita_id, paciente=request.user)
    cita.delete()
    return redirect('listar_citas')

def servicios(request):
    return render(request, 'crud_app/servicios.html')

def programas(request):
    return render(request, 'crud_app/programas.html')

def sobre_nosotros(request):
    return render(request, 'crud_app/sobre_nosotros.html')

def laboratorio(request):
    return render(request, 'crud_app/laboratorio.html')

def imagenologia(request):
    return render(request, 'crud_app/imagenologia.html')

def autorizaciones(request):
    return render(request, "crud_app/autorizaciones.html")

@login_required
def medicamentos(request):
    recetas = Receta.objects.filter(paciente=request.user).order_by('-fecha')

    return render(request, "crud_app/medicamentos.html", {
        "Recetas": recetas
    })


@login_required
def incapacidades(request):
    incapacidades = Incapacidad.objects.filter(paciente=request.user).order_by('-fecha_inicio')

    return render(request, "crud_app/incapacidades.html", {
        "incapacidades": incapacidades
    })


@login_required
def laboratorio(request):
    usuario = request.user

    try:
        perfil = PerfilUsuario.objects.get(user=usuario)
    except PerfilUsuario.DoesNotExist:
        perfil = None

    contexto = {
        "nombre_completo": f"{usuario.first_name} {usuario.last_name}",
        "correo": usuario.email,
        "eps": perfil.eps if perfil else "No registrado",
        "documento": perfil.numero_documento if perfil else "No disponible",
        "sedes": SedeLaboratorio.objects.all(),
    }

    return render(request, "crud_app/laboratorio.html", contexto)



def api_fechas_disponibles(request):
    sede_id = request.GET.get("sede")
    fechas = FechaDisponibleLab.objects.filter(sede_id=sede_id)

    data = []

    for f in fechas:
        horas = f.horas.filter(disponible=True)
        data.append({
            'fecha': f.fecha.strftime("%Y-%m-%d"),
            'horas': [h.hora.strftime("%H:%M") for h in horas]
        })

    return JsonResponse(data, safe=False)

from django.http import JsonResponse
from .models import PerfilUsuario


def buscar_paciente_por_documento(request):
    numero = request.GET.get("numero", "").strip()

    if numero == "":
        return JsonResponse({"exists": False})

    try:
        perfil = PerfilUsuario.objects.get(numero_documento=numero)
        user = perfil.user
        
        return JsonResponse({
            "exists": True,
            "nombre": f"{user.first_name} {user.last_name}"
        })
    except PerfilUsuario.DoesNotExist:
        return JsonResponse({"exists": False})
    


def logout_view(request):
    logout(request)
    return redirect('login')



