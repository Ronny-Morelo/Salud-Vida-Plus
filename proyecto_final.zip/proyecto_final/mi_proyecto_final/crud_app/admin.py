from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import User
from .models import PerfilUsuario
from django.contrib import admin
from .models import Especialidad, Medico, Cita, HorarioDisponible

admin.site.register(PerfilUsuario)

class CustomUserAdmin(UserAdmin):

    # Campos adicionales visibles dentro de Personal info
    readonly_fields = (
        'profile_eps',
        'profile_documento',
    )

    fieldsets = (
        ("Credenciales", {"fields": ("username", "password")}),
        
        ("Personal info", {
            "fields": (
                "first_name",
                "last_name",
                "email",
                "profile_eps",         # ← APARECE AQUÍ
                "profile_documento",   # ← APARECE AQUÍ
            )
        }),

        ("Permissions", {
            "fields": (
                "is_active",
                "is_staff",
                "is_superuser",
                "groups",
                "user_permissions",
            )
        }),

        ("Important dates", {"fields": ("last_login", "date_joined")}),
    )

    # Métodos para mostrar valores del perfil
    def profile_eps(self, obj):
        return obj.perfilusuario.eps
    profile_eps.short_description = "EPS"

    def profile_documento(self, obj):
        return obj.perfilusuario.numero_documento
    profile_documento.short_description = "Número de documento"


# Remplazar admin original
admin.site.unregister(User)
admin.site.register(User, CustomUserAdmin)

@admin.register(Medico)
class MedicoAdmin(admin.ModelAdmin):
    list_display = ('usuario', 'especialidad', 'dias_trabajo', 'hora_inicio', 'hora_fin')

    #  Esta función se ejecuta al guardar o actualizar un médico
    def save_model(self, request, obj, form, change):
        super().save_model(request, obj, form, change)
        # Primero, eliminamos horarios antiguos (para evitar duplicados)
        HorarioDisponible.objects.filter(medico=obj).delete()
        # Luego generamos los nuevos horarios según sus días y horas
        HorarioDisponible.generar_horarios(obj)

@admin.register(Especialidad)
class EspecialidadAdmin(admin.ModelAdmin):
    list_display = ('nombre',)

@admin.register(Cita)
class CitaAdmin(admin.ModelAdmin):
    list_display = ('paciente', 'medico', 'fecha', 'estado')

@admin.register(HorarioDisponible)
class HorarioDisponibleAdmin(admin.ModelAdmin):
    list_display = ('medico', 'fecha', 'hora', 'disponible')

from .models import (
    SedeLaboratorio, FechaDisponibleLab, HoraDisponibleLab
)

@admin.register(SedeLaboratorio)
class SedeLaboratorioAdmin(admin.ModelAdmin):
    list_display = ('id', 'nombre')


class HoraDisponibleInline(admin.TabularInline):
    model = HoraDisponibleLab
    extra = 1


@admin.register(FechaDisponibleLab)
class FechaDisponibleLabAdmin(admin.ModelAdmin):
    list_display = ('sede', 'fecha')
    inlines = [HoraDisponibleInline]


@admin.register(HoraDisponibleLab)
class HoraDisponibleLabAdmin(admin.ModelAdmin):
    list_display = ('fecha', 'hora', 'disponible')

