from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth.models import User
from .models import PerfilUsuario, Medico

# Crear perfil automáticamente cuando se crea un User
@receiver(post_save, sender=User)
def crear_perfil_usuario(sender, instance, created, **kwargs):
    if created:
        PerfilUsuario.objects.create(user=instance)

# Guardar perfil o crearlo si no existe
@receiver(post_save, sender=User)
def guardar_perfil_usuario(sender, instance, **kwargs):
    try:
        instance.perfilusuario.save()
    except PerfilUsuario.DoesNotExist:
        PerfilUsuario.objects.create(user=instance)

# Asignar rol MEDICO automáticamente al crear un registro en Medico
@receiver(post_save, sender=Medico)
def asignar_rol_medico(sender, instance, created, **kwargs):
    if created:
        perfil, _ = PerfilUsuario.objects.get_or_create(user=instance.usuario)
        perfil.rol = "MEDICO"
        perfil.save()